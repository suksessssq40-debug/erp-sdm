'use client';
import { ProjectDetail } from '@/components/ProjectDetail';

export default function ProjectDetailPage() {
  return <ProjectDetail />;
}
