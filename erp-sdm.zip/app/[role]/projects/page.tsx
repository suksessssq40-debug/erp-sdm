'use client';
import { ProjectList } from '@/components/ProjectList';

export default function ProjectsPage() {
  return <ProjectList />;
}
